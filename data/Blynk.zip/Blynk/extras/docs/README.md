## Please take a look at:
[Blynk Firmware Documentation](https://docs.blynk.io/en/blynk.edgent-firmware-api/supported-boards) 
